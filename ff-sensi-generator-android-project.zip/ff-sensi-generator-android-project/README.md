# FF Sensi Generator — Android Project

Package: `com.ffsensigenerator.app`
Version: `1.0.0`
Target SDK: 36 (Android 16)

## What this is
A lightweight Android WebView wrapper prepared for the FF Sensi Generator PWA.

## Before release
1. Replace `app/src/main/assets/www/` with the final web app files.
2. Add a real launcher icon under `app/src/main/res/` (do not use placeholder/empty PNGs).
3. Open the project in Android Studio.
4. Let Gradle sync.
5. Build a signed **Android App Bundle (.aab)** for Google Play.
6. Test the release build on an Android phone.
7. In Play Console, complete the store listing, Data Safety, privacy policy and required testing/release steps.

## Future VIP Premium
The package and project are intentionally structured so a later release can add VIP Sensi Premium without changing the application ID.

## Note
This project is a starting Android wrapper. The final AAB must be built and signed with Android tooling before Play Store submission.
